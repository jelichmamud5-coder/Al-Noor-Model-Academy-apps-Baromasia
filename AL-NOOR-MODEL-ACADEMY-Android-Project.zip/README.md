# AL-NOOR MODEL ACADEMY — Android School Management System

This repository is the Android foundation for a Firebase-backed school-management application.

## Included
- Kotlin + Jetpack Compose + Material 3
- Four-role login architecture: Super Admin, Teacher, Parent, Student
- Role-specific dashboard/module structure
- Firebase Authentication/Firestore/Storage/FCM dependencies
- Firestore and Storage security-rule starting point
- Mobile/cloud build workflow

## Firebase setup
1. Create a Firebase project.
2. Register Android app with package:
   `com.alnoor.modelacademy`
3. Download `google-services.json`.
4. Put it at:
   `app/google-services.json`
5. Uncomment the Google Services plugin in `app/build.gradle.kts`.
6. Enable Email/Password Authentication and Firestore.
7. Deploy the included rules after reviewing them for your production tenant model.

## Important
This starter contains no fake users, marks, fees or demo school records. Firebase authentication and role records must be configured before real login can work.

Recommended user document:
`users/{uid}`
```json
{
  "role": "SUPER_ADMIN",
  "schoolId": "YOUR_SCHOOL_ID",
  "active": true
}
```

## Build
From a computer with Android SDK:
`gradle :app:assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

For mobile-only building, push this project to GitHub and use the included GitHub Actions workflow.
