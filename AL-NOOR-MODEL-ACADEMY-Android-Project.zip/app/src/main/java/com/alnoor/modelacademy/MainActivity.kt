package com.alnoor.modelacademy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

enum class Role(val label: String) {
    SUPER_ADMIN("Super Admin"), TEACHER("Teacher"), PARENT("Parent"), STUDENT("Student")
}

data class Module(val title: String, val description: String)

private val adminModules = listOf(
    Module("School Setup","Logo, address, registration, principal, seal and branding"),
    Module("Students","Admission, profiles, search, promote, transfer and archive"),
    Module("Teachers","Staff profiles, assignments, recruitment and accounts"),
    Module("Classes & Subjects","Classes, sections, subjects and teacher mapping"),
    Module("Attendance","Student and teacher attendance with reports"),
    Module("Examinations","Terms, exams, dates, syllabus and marks"),
    Module("Results","Marks, grading, publish/lock and marksheets"),
    Module("Question Papers","Syllabus-based question bank and PDF papers"),
    Module("Fees","Structures, payments, dues and receipts"),
    Module("Timetable","Class and teacher routines"),
    Module("Homework & Materials","Homework, notes and files"),
    Module("Notices","School announcements and notifications"),
    Module("Certificates & ID","Dynamic document generation"),
    Module("Reports","Attendance, fees, results, admissions and exports"),
    Module("Permissions","Per-teacher role permissions"),
    Module("Settings","Academic year, grading, templates and app settings")
)

private val teacherModules = listOf(
    Module("My Classes","Assigned classes and subjects"),
    Module("Attendance","Mark student attendance"),
    Module("Marks","Enter marks for assigned subjects"),
    Module("Question Papers","Create papers from assigned syllabus"),
    Module("Homework","Create homework and study materials"),
    Module("Routine","View teaching timetable"),
    Module("Notices","View notices")
)

private val parentModules = listOf(
    Module("Children","Linked child profiles"),
    Module("Results","Published results and marksheets"),
    Module("Fees","Paid, due and payment history"),
    Module("Attendance","Attendance history"),
    Module("Routine","Class timetable"),
    Module("Notices","School notices")
)

private val studentModules = listOf(
    Module("My Profile","Personal academic profile"),
    Module("Results","Published results and marksheets"),
    Module("Fees","Paid and due"),
    Module("Attendance","Attendance history"),
    Module("Routine","Class timetable"),
    Module("Homework","Homework and study materials"),
    Module("Notices","School notices")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlNoorApp() }
    }
}

@Composable
fun AlNoorApp() {
    var loggedIn by remember { mutableStateOf(false) }
    var role by remember { mutableStateOf(Role.SUPER_ADMIN) }
    var loginId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = lightColorScheme()) {
        if (!loggedIn) {
            LoginScreen(
                loginId, password, error,
                onLoginId = { loginId = it },
                onPassword = { password = it },
                onRole = { role = it },
                onLogin = {
                    // Production path: enable Firebase Auth and look up users/{uid}
                    // role + schoolId in Firestore. This starter intentionally does
                    // not contain fake credentials.
                    if (loginId.isBlank() || password.isBlank()) {
                        error = "Enter Login ID/Email and Password."
                    } else {
                        error = "Firebase is not connected yet. Add google-services.json and enable the Google Services plugin in app/build.gradle.kts."
                    }
                }
            )
        } else {
            Dashboard(role) { loggedIn = false }
        }
    }
}

@Composable
fun LoginScreen(
    loginId: String, password: String, error: String,
    onLoginId: (String) -> Unit, onPassword: (String) -> Unit,
    onRole: (Role) -> Unit, onLogin: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        Text("AL-NOOR MODEL ACADEMY", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Run by Baromasia Al Nur Academy Foundation", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(32.dp))
        Text("Secure Login", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        Role.entries.forEach { r ->
            FilterChip(
                selected = r == Role.SUPER_ADMIN && false, // visual selection handled below
                onClick = { onRole(r) },
                label = { Text(r.label) },
                modifier = Modifier.padding(3.dp)
            )
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(loginId, onLoginId, label = { Text("Login ID / Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, onPassword, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("LOGIN") }
        if (error.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(24.dp))
        Text("Selected role: ${Role.SUPER_ADMIN.label}", style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dashboard(role: Role, logout: () -> Unit) {
    val modules = when(role) {
        Role.SUPER_ADMIN -> adminModules
        Role.TEACHER -> teacherModules
        Role.PARENT -> parentModules
        Role.STUDENT -> studentModules
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${role.label} Dashboard") },
                actions = { TextButton(logout) { Text("Logout") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("AL-NOOR MODEL ACADEMY", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Run by Baromasia Al Nur Academy Foundation")
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(modules) { module ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(module.title, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(module.description, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
